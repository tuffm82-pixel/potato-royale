# PLAY POTATO ROYALE

**[Play the running local preview](http://127.0.0.1:4174/)** — works on the computer running this project.

For the downloaded game, extract the ZIP, run `npm start`, and open **[Play Potato Royale](http://127.0.0.1:4173/)**. Node.js 22 or newer is required; no dependency installation is needed. Windows users can double-click `PLAY.cmd`.

**Public GitHub play link, not published yet:** [Potato Royale on GitHub Pages](https://tuffm82-pixel.github.io/potato-royale/). It will work only after the repository is uploaded and its Pages workflow finishes. The connected GitHub account currently has no access to the requested destination.

## Play with people

Choose **PLAY ONLINE** or **Friends**. Exchange friend codes, press **Add**, then **Challenge**. Accept the invitation on the other player's screen. You can also create a room and share its code, or press **FIND A PLAYER** to join the public queue. Empty queues wait for a person; there are no substitute bots.

Both players must reach the same running multiplayer server. This release includes that server. GitHub Pages hosts only the interface; worldwide multiplayer also needs the Node server hosted over HTTPS. Open **Friends → Game server** to select it. Public matches advance the device's trophy road; friend battles do not. Online cards are normalized to level 1.

**Practice** is separately labelled and uses a computer opponent. Every card has **Try in practice** in its details.

## Champions

Deployment and abilities are separate purchases. Deploy a Champion, then press **Use [ability] · +[cost] oil** to activate its ability. Nothing activates automatically for you. The button shows the extra oil cost and cooldown.

| Champion | Deployment | Separate ability | Extra oil |
|---|---:|---|---:|
| Potato Man | 5 | Fly Form | 2 |
| Super Spud | 5 | Lightning Lord | 2 |
| Chef | 2 | Sharpened Senses | 2 |
| Barry | 3 | Barry's Backup | 3 |
| Greg the Sausage | 5 | Sizzle Burst | 2 |
| Stick Man | 2 | Sketch Summon | 2 |

Stick Man draws Spud Scout (50%), Honey Mauler (30%), Quartz Sentinel (15%), or Potato Man (5%). The summoned Potato Man does not have a second ability button. A deck still has at most one Champion.
