# Potato Royale

**[How to play → PLAY.md](PLAY.md)**

A portrait card battler based on the creator's homemade comic. The illustrations use rough pencil outlines, broken coloured-pencil strokes and uncoloured paper. Original Champion drawings remain the reference for their identities.

## Run

Use Node.js 22 or newer. No dependencies are required.

```sh
npm start
```

Open http://127.0.0.1:4173/. The active development preview uses port 4174. Windows users can launch `PLAY.cmd`.

## Included

- 127 cards with unique names; no named role occurs more than twice. Existing card IDs preserve old saves.
- Six rarity colours, orange glowing Champion frames, eight-card decks and at most one Champion per deck.
- Six Champions with separate paid ability buttons. Stick Man replaces the three breadsticks and costs 2 oil; Sketch Summon costs another 2.
- A much larger paper battlefield, sparse pencil colouring, and human occupants inside the towers.
- Real-player public matchmaking, friend codes, invitations and private room codes. Empty queues never spawn bots.
- Server-owned battle simulation, oil, placement, cooldown and deck validation. Online cards use level 1.
- Thirty arenas and an increasingly demanding trophy road. Public online results award device-local progression; friend matches and computer practice do not. Match claims persist to prevent repeat rewards on reconnect.
- Daily rewards, card upgrades, chests, three saved decks and local clan notes.

This is a self-hostable multiplayer prototype. There is no global account ladder or online clan chat. Progress stays in browser storage. Friend identities belong to the connected server. Clearing browser data loses the guest token and local save. The optional GitHub-only moderator menu is omitted because verified GitHub authentication has not been configured.

## Hosting real multiplayer

`server.cjs` serves the game and its JSON API; `multiplayer-server.cjs` runs matches. Use one Node process with a persistent disk for `.data/players.json`. Live matches are in memory and end on a server restart. Guest bearer tokens are random; only their hashes are stored on disk. Do not publish `.data/`.

Set `HOST=0.0.0.0` and the host's `PORT` to accept remote connections. Put HTTPS in front of the server before exposing guest tokens remotely. If the frontend is hosted elsewhere, set `ALLOWED_ORIGINS` to its exact origin, for example `https://tuffm82-pixel.github.io`; multiple allowed origins use commas. Players enter the HTTPS server address in **Friends → Game server**. Both players must use the same server.

Friends are added by exchanging codes. Challenge an added friend, accept their invitation, or share an unlisted room code. A disconnected player forfeits after 30 seconds. Waiting rooms expire after five minutes.

## GitHub Pages

The intended destination from the earlier request is `tuffm82-pixel/potato-royale`. The later shorthand account `tuffm82` returned no public account in the final check. No upload has succeeded: the GitHub connection exposes no repositories or installations, and the browser requires sign-in.

With write access, create the repository, upload this source to `main`, then choose **Settings → Pages → GitHub Actions**. `.github/workflows/pages.yml` runs tests, builds the public allowlist into `dist/`, and deploys it. `PLAY.md` contains the planned play link, explicitly marked unpublished. Pages alone cannot run the multiplayer server.

## Development

```sh
npm test
npm run art
npm run build
```

Tests cover deck rules, all Champion abilities, summon probability boundaries, save migration, reward replay prevention, real HTTP clients, friend invitations, disconnects and private-file protection. The art generator preserves the four original Champion PNGs and the generated tower sprite. Generated SVG cards are project assets, not placeholders.

The release ZIP contains the server, frontend, tests, artwork, Pages workflow and this guide. It excludes reference photos, guest data, Git credentials, caches and local saves.

## In-game animation
All 127 cards have deterministic paper-cutout motion profiles. Troops walk, hop, float, slither, scuttle or waddle according to their silhouette, with six distinct Champion gaits. Combat adds deployment, attack, hit, healing and defeat motions, tower recoil, travelling projectiles, spell illustrations and labelled Champion bursts. Persistent DOM nodes keep animations from restarting each frame. Pause freezes visual motion; reduced-motion preferences suppress decorative movement. These are live cutout animations of the existing illustrations, not newly redrawn frame-by-frame sprite sheets.
