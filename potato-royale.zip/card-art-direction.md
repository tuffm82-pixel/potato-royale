# Potato Royale art direction

The user's homemade drawings establish both identity and style. Current direction: wobbly dark pencil contours, scribbled coloured-pencil filling, simple eyes, flat shapes and uneven proportions. Polished digital cel shading, glossy bodies and realistic anatomy were rejected.

Potato Man retains his red cape and red belly badge; Super Spud his oval body and blue lightning; Chef his angular face, tall white hat and simple coat; Barry his round body, grey beanie and moustache. Greg is a sausage. The Three French Men are three breadsticks. Barry's Backup consists of two carrot guards.

The four supplied Champions were generated with the built-in image tool from the original photos, then saved in assets/cards/ and assets/units/. Shared final prompt: "Faithfully redraw only the single main character; preserve the reference's rough coloured-pencil and wobbly black-pencil style, flat shapes, original proportions and simple eyes. Full character centered on transparency; no paper, frame, lettering, gradients, glossy rendering or redesigned anatomy." Each prompt also names the identity details above.

The other 123 cards use deterministic original SVG artwork: food-specific silhouettes, role equipment, pencil hatch fills, and irregular contours. They are visual role variants, not 123 distinct special abilities.

The interface uses cream paper, dark borders, halftone panels, captions and speech bubbles. Rarity colors remain visible; Champions retain glowing orange gradient frames. Names, costs and stats are readable HTML. Battlefield geometry stays at two bridges (23%/77% width) and a river at 50% height.


## 2026-10-22 revision
The three breadsticks are replaced by one Stick Man holding a pencil. The roster has unique identities with no named role repeated more than twice. Existing IDs remain for save compatibility. Generic cards now use varied creature and object silhouettes, rough double graphite contours, partial coloured strokes, white paper gaps and separate props. Four supplied Champion PNGs remain unchanged.

The built-in image tool generated assets/maps/pencil-battlefield.png using the original drawings as style references: overhead portrait kitchen playground, paper-white open center, sparse scribbled green and ochre paths, stream at 50%, bridges at 23/77%, no labels or towers. A follow-up edit removed empty tower foundation boxes while preserving the drawing. It generated assets/units/tower-keeper.png: naive pencil watchtower, a clearly visible human head, torso and hands above its parapet, sparse coloured pencil on transparency. These are project assets; no CLI image API or image resizing was used.
