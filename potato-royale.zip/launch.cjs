'use strict';
const {spawn}=require('node:child_process'),{createServer}=require('./server.cjs');
const server=createServer(),url='http://127.0.0.1:4173/';
server.on('error',error=>{console.error(error.code==='EADDRINUSE'?'Port 4173 is already in use. Close the other game server and try again.':error.message);process.exitCode=1;server.close();});
server.listen(4173,'127.0.0.1',()=>{console.log('Potato Royale: '+url+'\nKeep this window open while playing.');if(process.platform==='win32'){const browser=spawn('cmd',['/c','start','',url],{windowsHide:true,stdio:'ignore'});browser.on('error',()=>console.log('Open the play address in your browser.'));browser.unref();}});
