'use strict';
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..'),out=path.join(root,'dist');
// Only this generated child directory may be replaced; never follow a link.
if(path.dirname(out)!==root||path.basename(out)!=='dist')throw Error('Unsafe output directory');
if(fs.existsSync(out)&&fs.lstatSync(out).isSymbolicLink())throw Error('Refusing linked output directory');
const context={window:{}};
vm.runInNewContext(fs.readFileSync(path.join(root,'card-art.js'),'utf8'),context);
const files=new Set(['index.html','styles.css','comic.css','app.js','animations.js','animations.css','online.js','game-core.js','card-art.js','assets/maps/comic-kitchen.svg','assets/maps/pencil-battlefield.png','PLAY.md',...Object.values(context.window.POTATO_ART),...Object.values(context.window.POTATO_UNITS)]);
for(const file of files){if(path.isAbsolute(file)||file.split(/[\\/]/).includes('..')||!fs.statSync(path.join(root,file)).isFile())throw Error('Invalid or missing public asset: '+file);}
if(fs.existsSync(out))fs.rmSync(out,{recursive:true});
for(const file of files){const dest=path.join(out,file);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(path.join(root,file),dest);}
fs.writeFileSync(path.join(out,'.nojekyll'),'');
console.log(`Built ${files.size} public game files in dist/. No reference photos, save data, or development notes included.`);
