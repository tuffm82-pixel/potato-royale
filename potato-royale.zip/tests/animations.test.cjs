'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),G=require('../game-core.js'),A=require('../animations.js');
test('every character has a deterministic motion profile and Champions have distinct gaits',()=>{
 const gaits=new Set();for(const c of G.CARDS){const a=A.describe(c);assert.deepEqual(a,A.describe(c));assert.ok(a.duration>=.48&&a.duration<=1);assert.ok(['swing','recoil','throw','heal'].includes(a.attack));gaits.add(a.gait);}
 assert.ok(gaits.size>=11);assert.equal(new Set(G.CARDS.filter(c=>c.rarity==='champion').map(c=>A.describe(c).gait)).size,6);
});
test('animation cues are absent before action, expire, and tolerate zero timestamps',()=>{
 assert.deepEqual(A.pose({},0),{moving:false,attacking:false,hurt:false,healing:false,casting:false});
 assert.equal(A.pose({attackAt:0},.1).attacking,true);assert.equal(A.pose({attackAt:0},.4).attacking,false);assert.equal(A.pose({attackAt:2},1).attacking,false);
});
test('server attack and damage cues carry target positions without changing damage',()=>{
 const p=G.newProfile(),b=G.createBattle(p,true);b.online=true;b.decks.player[0]='pea-shooter';b.decks.enemy[0]='spud-scout';b.energy={player:10,enemy:10};G.deploy(b,'player',0,23,55);G.deploy(b,'enemy',0,23,45);
 const [a,target]=b.units;a.ready=0;target.ready=999;const hp=target.hp;G.tick(b,.1);
 assert.equal(target.hp,hp-a.damage);assert.equal(a.attackAt,b.elapsed);assert.equal(target.hitAt,b.elapsed);assert.deepEqual(a.attackTarget,{x:23,y:45});
 const fx=b.effects.find(e=>e.kind==='shot');assert.equal(fx.fromX,23);assert.equal(fx.fromY,55);assert.equal(fx.y,45);assert.ok(fx.life>=1,'survives the online polling interval');assert.ok(fx.id);
});
test('walking and separate paid Champion casts emit presentation cues',()=>{
 const p=G.newProfile();p.owned.chef={level:1,copies:1};p.decks[0][0]='chef';const b=G.createBattle(p,true);b.online=true;b.energy.player=10;G.deploy(b,'player',0,50,80);const chef=b.units[0];chef.ready=0;
 assert.equal(chef.abilityAt,undefined);G.tick(b,.1);assert.equal(chef.movedAt,b.elapsed);const oil=b.energy.player;G.activateAbility(b,'player');assert.equal(chef.abilityAt,b.elapsed);assert.equal(b.energy.player,oil-2);assert.equal(b.effects.at(-1).kind,'chef');
});
