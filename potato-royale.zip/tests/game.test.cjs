const {test}=require('node:test');
const assert=require('node:assert/strict');
const G=require('../game-core.js');
test('catalog has 127 unique cards and the six comic Champions',()=>{
  assert.equal(G.CARDS.length,127);assert.equal(new Set(G.CARDS.map(c=>c.id)).size,127);
  for(const id of ['potato-man','greg-the-sausage','barry','three-french-men','super-spud','chef'])assert.equal(G.card(id).rarity,'champion');
});
test('all 30 arenas have increasingly expensive progression',()=>{
  assert.equal(G.ARENAS.length,30);
  for(let i=2;i<30;i++)assert.ok(G.ARENAS[i].trophies-G.ARENAS[i-1].trophies>G.ARENAS[i-1].trophies-G.ARENAS[i-2].trophies);
  assert.equal(G.arenaFor(1e8).number,30);
});
test('decks reject locked, duplicate, and incomplete cards',()=>{
 const s=G.newProfile();assert.ok(G.validDeck(s,s.decks[0]));assert.ok(!G.validDeck(s,Array(8).fill(s.decks[0][0])));assert.ok(!G.validDeck(s,['barry',...s.decks[0].slice(1)]));assert.ok(!G.validDeck(s,[]));
});
test('deployment consumes energy only for valid friendly-side placements',()=>{
 const s=G.newProfile(),b=G.createBattle(s,false,()=>0.5);const energy=b.energy.player;
 assert.equal(G.deploy(b,'player',0,20,10),false);assert.equal(b.energy.player,energy);
 assert.ok(G.deploy(b,'player',0,24,82));assert.ok(b.energy.player<energy);assert.ok(b.units.length);
});
test('a battle ends, grants ranked results once, and training grants none',()=>{
 const s=G.newProfile(),b=G.createBattle(s,false,()=>0.4);b.towers.find(t=>t.side==='enemy'&&t.king).hp=0;G.tick(b,0.1);assert.equal(b.result,'win');
 const trophies=s.trophies;assert.ok(G.settle(s,b));assert.ok(s.trophies>trophies);assert.equal(G.settle(s,b),null);
 const practice=G.createBattle(s,true);practice.result='win';const before=s.trophies;G.settle(s,practice);assert.equal(s.trophies,before);
});
test('reward claims and upgrades cannot spend unavailable currency',()=>{
 const s=G.newProfile();const initial=s.gold;s.gold=0;assert.equal(G.upgrade(s,s.decks[0][0]),false);assert.equal(s.gold,0);s.gold=initial;
 const b=G.createBattle(s,false);b.result='win';G.settle(s,b);assert.equal(s.chests.length,1);assert.ok(G.claimChest(s,s.chests[0].id,Date.now()+1e8));assert.equal(s.chests.length,0);assert.equal(G.claimChest(s,'missing'),null);
});
test('invalid stored state restores a safe profile',()=>{
 assert.ok(G.validDeck(G.loadProfile({decks:[['bad']],gold:-2}),G.newProfile().decks[0]));
 const s=G.newProfile();s.gold=999;s.name='<test>';const restored=G.loadProfile(JSON.parse(JSON.stringify(s)));assert.equal(restored.gold,999);assert.equal(restored.name,'<test>');
});
test('full matches finish with finite state even when the player does nothing',()=>{
 for(const trophies of [0,G.ARENAS[29].trophies]){
  const s=G.newProfile();s.trophies=trophies;const b=G.createBattle(s,false,()=>.3);
  for(let i=0;i<1810&&!b.result;i++)G.tick(b,.1);
  assert.ok(['win','draw','loss'].includes(b.result));
  assert.ok(b.towers.every(t=>Number.isFinite(t.hp)));
  assert.ok(b.units.every(u=>Number.isFinite(u.x)&&Number.isFinite(u.y)));
  assert.ok(b.energy.player>=0&&b.energy.player<=10);
 }
});
test('deck edits are atomic, owned-only, and limited to one Champion',()=>{
 const s=G.newProfile();for(const id of ['potato-man','barry'])s.owned[id]={level:1,copies:0};
 assert.equal(G.replaceCard(s,0,0,'potato-man').ok,true);
 const before=[...s.decks[0]];assert.equal(G.replaceCard(s,0,1,'barry').ok,false);assert.deepEqual(s.decks[0],before);
 assert.equal(G.replaceCard(s,0,1,'potato-man').ok,false);
 assert.equal(G.replaceCard(s,0,1,'tomato-wizard').ok,false);
 assert.equal(G.replaceCard(s,0,1,'radish-runner').ok,true);
 assert.equal(G.deckReport(s,s.decks[0]).valid,true);
});
test('card roles, combat rules and upgrade requirements are explicit',()=>{
 assert.equal(G.card('turnip-tank').targets,'buildings');
 assert.equal(G.card('mushroom-medic').type,'healer');
 assert.equal(G.card('garlic-mage').splash,8);
 assert.equal(G.card('chilli-burst').type,'spell');
 const s=G.newProfile();s.gold=0;assert.match(G.upgradeReport(s,'spud-scout').reason,/gold/i);
 assert.ok(G.CARDS.every(c=>c.attackInterval>0&&c.deployTime>=0&&c.targets));
});
test('tank ignores nearby troops and healer never deals enemy damage',()=>{
 const s=G.newProfile();s.decks[0][0]='turnip-tank';s.decks[0][7]='spud-scout';
 const b=G.createBattle(s,true);b.ai=999;b.towers.forEach(t=>t.cd=999);G.deploy(b,'player',0,23,60);const tank=b.units[0];tank.ready=0;
 b.units.push({...G.stats(G.card('spud-scout')),id:'bait',side:'enemy',x:23,y:59,hp:999,maxHp:999,cd:0,ready:999});G.tick(b,.1);assert.equal(b.units.find(u=>u.id==='bait').hp,999);
 const h=G.createBattle(G.newProfile(),true);h.ai=999;h.towers.forEach(t=>t.cd=999);h.decks.player[0]='mushroom-medic';G.deploy(h,'player',0,23,60);h.units[0].ready=0;
 h.units.push({...G.stats(G.card('spud-scout')),id:'enemy-bait',side:'enemy',x:23,y:59,hp:999,maxHp:999,cd:0,ready:999});G.tick(h,.1);assert.equal(h.units.find(u=>u.id==='enemy-bait').hp,999);
});
test('Champion ability consumes cooking oil, enforces cooldown, and expires',()=>{
 const s=G.newProfile();s.owned['potato-man']={level:1,copies:0};s.decks[0][0]='potato-man';
 const b=G.createBattle(s,true);b.ai=999;b.energy.player=10;assert.ok(G.deploy(b,'player',0,23,70));
 assert.equal(G.abilityReport(b,'player').ready,false);G.tick(b,.1);b.units.forEach(u=>u.ready=0);
 const before=b.energy.player;assert.ok(G.activateAbility(b,'player'));assert.equal(b.energy.player,before-2);assert.ok(b.units[0].flyingUntil>b.elapsed);
 assert.equal(G.activateAbility(b,'player'),false);for(let i=0;i<70;i++)G.tick(b,.1);assert.ok(b.units[0].flyingUntil<b.elapsed);
});
test('troops wait for deployment and spells deal reduced damage to towers',()=>{
 const s=G.newProfile(),b=G.createBattle(s,true);b.ai=999;G.deploy(b,'player',0,23,60);const u=b.units[0],y=u.y;G.tick(b,.1);assert.equal(u.y,y);
 b.energy.player=10;b.decks.player[0]='chilli-burst';const t=b.towers.find(t=>t.side==='enemy'&&!t.king);const hp=t.hp;assert.ok(G.deploy(b,'player',0,t.x,t.y));assert.equal(t.hp,hp-Math.round(G.card('chilli-burst').damage*.4));
});
test('all six Champion abilities apply the advertised effects',()=>{
 for(const id of ['potato-man','greg-the-sausage','barry','three-french-men','super-spud','chef']){
  const s=G.newProfile();s.owned[id]={level:1,copies:0};s.decks[0][0]=id;const b=G.createBattle(s,true);b.ai=999;b.energy.player=10;G.deploy(b,'player',0,23,70);
  b.units.forEach(u=>{u.ready=0;u.hp=u.maxHp-100;});b.units.push({...G.stats(G.card('spud-scout')),id:'target',cardId:'spud-scout',side:'enemy',x:23,y:69,hp:1000,maxHp:1000,ready:999,cd:999});
  const champion=b.units[0],oldHp=champion.hp;assert.ok(G.activateAbility(b,'player'));
  if(id==='potato-man')assert.equal(champion.flyingUntil,6);
  if(id==='greg-the-sausage')assert.equal(b.units.find(u=>u.id==='target').hp,780);
  if(id==='barry'){assert.equal(b.units.filter(u=>u.cardId==='carrot-backup').length,2);assert.equal(champion.hp,oldHp);}
  if(id==='super-spud'){assert.equal(b.units.find(u=>u.id==='target').hp,760);assert.equal(b.units.find(u=>u.id==='target').stunUntil,1.2);}
  if(id==='chef')assert.equal(champion.focusUntil,6);
  if(id==='three-french-men'){assert.equal(b.units.filter(u=>u.side==='player').length,2);assert.equal(b.units.filter(u=>u.side==='player'&&u.summoned).length,1);}
  b.units.filter(u=>u.side==='player').forEach(u=>u.hp=0);assert.equal(G.abilityReport(b,'player').exists,false);
 }
});
test('Stick Man cannot redeploy while the deployed Champion survives',()=>{
 const s=G.newProfile();s.owned['three-french-men']={level:1,copies:0};s.decks[0][0]='three-french-men';const b=G.createBattle(s,true);b.energy.player=10;G.deploy(b,'player',0,23,70);
 b.decks.player[0]='three-french-men';b.energy.player=10;assert.equal(G.deploy(b,'player',0,23,70),false);
 b.units.forEach(u=>u.hp=0);assert.equal(G.deploy(b,'player',0,23,70),true);
});
test('reloading preserves daily reward cooldown and Champion deck limits',()=>{
 const s=G.newProfile(),now=Date.now();assert.ok(G.claimDaily(s,now));
 const restored=G.loadProfile(JSON.parse(JSON.stringify(s)));assert.equal(G.claimDaily(restored,now+1000),false);
 s.owned['potato-man']={level:1,copies:0};s.owned.barry={level:1,copies:0};s.decks[0][0]='potato-man';s.decks[0][1]='barry';
 const recovered=G.loadProfile(s);assert.ok(G.validDeck(recovered,recovered.decks[0]));
});

function championBattle(id,side='player'){
 const s=G.newProfile();s.owned[id]={level:1,copies:0};s.decks[0][0]=id;
 const b=G.createBattle(s,true);b.ai=999;b.towers.forEach(t=>t.cd=999);b.decks[side][0]=id;b.energy[side]=10;
 assert.ok(G.deploy(b,side,0,50,side==='player'?60:40));const u=b.units[0];u.ready=0;return {b,u};
}
function target(b,id,x=50,y=59,side='enemy'){
 const u={...G.card(id),id:'target-'+b.units.length,cardId:id,side,x,y,maxHp:10000,hp:10000,ready:0,cd:0};
 b.units.push(u);return u;
}
test('all Champions charge exact deploy and ability oil once',()=>{
 for(const [id,cost,ability] of [['potato-man',5,2],['super-spud',5,2],['chef',2,2],['barry',3,3]]){
  const {b}=championBattle(id);assert.equal(b.energy.player,10-cost);
  b.energy.player=ability-.1;assert.equal(G.activateAbility(b,'player'),false);assert.equal(b.energy.player,ability-.1);
  b.energy.player=ability;assert.ok(G.activateAbility(b,'player'));assert.equal(b.energy.player,0);
  b.energy.player=10;assert.equal(G.activateAbility(b,'player'),false);assert.equal(b.energy.player,10);
 }
 assert.equal(G.card('super-spud').unlock,22);assert.equal(G.card('chef').unlock,24);
});
test('Fly Form bypasses bridges, blocks melee, and expires',()=>{
 const {b,u}=championBattle('potato-man');u.cd=999;G.activateAbility(b,'player');
 const melee=target(b,'spud-scout');const hp=u.hp;G.tick(b,.1);assert.equal(u.hp,hp);
 melee.hp=0;u.x=50;u.y=54;G.tick(b,.1);assert.ok(u.y<54);
 b.elapsed=6;u.x=50;u.y=60;const foe=target(b,'spud-scout');G.tick(b,.1);assert.equal(u.flyingUntil,0);assert.equal(u.hp,hp-foe.damage);
});
test('ranged attacks, towers and spells can damage Fly Form',()=>{
 for(const mode of ['ranged','tower','spell']){
  const {b,u}=championBattle('potato-man');G.activateAbility(b,'player');u.cd=999;const hp=u.hp;
  if(mode==='ranged'){target(b,'pea-shooter');G.tick(b,.1);}
  if(mode==='tower'){u.x=23;u.y=22;b.towers.find(t=>t.id==='enemy-23').cd=0;G.tick(b,.1);}
  if(mode==='spell'){b.decks.enemy[0]='chilli-burst';b.energy.enemy=10;G.deploy(b,'enemy',0,u.x,u.y);}
  assert.ok(u.hp<hp,mode);
 }
});
test('Lightning Lord stuns only nearby enemies and reduces tower damage',()=>{
 const {b,u}=championBattle('super-spud');const near=target(b,'spud-scout'),far=target(b,'spud-scout',90,10),ally=target(b,'spud-scout',50,59,'player');
 const tower=b.towers.find(t=>t.id==='enemy-23');tower.x=50;tower.y=50;const hp=tower.hp;
 G.activateAbility(b,'player');assert.equal(near.hp,9760);assert.equal(far.hp,10000);assert.equal(ally.hp,10000);assert.equal(tower.hp,hp-96);
 const y=near.y;u.cd=999;G.tick(b,.1);assert.equal(near.y,y);assert.equal(u.hp,u.maxHp);
 b.elapsed=1.3;G.tick(b,.1);assert.ok(ally.hp<10000);
});
test('Chef focus increases attack rate and damage then restores baseline',()=>{
 const {b,u}=championBattle('chef');const enemy=target(b,'spud-scout');enemy.ready=999;
 G.activateAbility(b,'player');G.tick(b,.1);assert.equal(enemy.hp,10000-Math.round(u.damage*1.25));assert.equal(u.cd,u.attackInterval/2);
 b.elapsed=6;u.cd=0;const hp=enemy.hp;G.tick(b,.1);assert.equal(u.focusUntil,0);assert.equal(enemy.hp,hp-u.damage);assert.equal(u.cd,u.attackInterval);
});
test('Barry summons two independent same-team ranged guards without Champion abilities',()=>{
 for(const side of ['player','enemy']){
  const {b,u}=championBattle('barry',side);const oil=b.energy[side];G.activateAbility(b,side);
  const guards=b.units.filter(t=>t.cardId==='carrot-backup');assert.equal(guards.length,2);assert.equal(b.energy[side],oil-3);
  assert.ok(guards.every(t=>t.side===side&&t.type==='ranged'&&t.rarity!=='champion'&&t.hp===260&&!t.ability));
  u.hp=0;assert.equal(G.abilityReport(b,side).exists,false);
  b.decks[side][0]='barry';b.energy[side]=10;assert.equal(G.deploy(b,side,0,23,side==='player'?70:30),true);
 }
});

