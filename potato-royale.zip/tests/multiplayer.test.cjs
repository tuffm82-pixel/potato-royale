'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createServer}=require('../server.cjs'),G=require('../game-core.js');
const deck=G.newProfile().decks[0];
async function setup(t,options={}){const server=createServer({dataFile:null,...options});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));t.after(()=>new Promise(resolve=>server.close(resolve)));const base=`http://127.0.0.1:${server.address().port}`;return {base,server,async request(route,data,token,headers={}){const response=await fetch(base+route,{method:data===undefined?'GET':'POST',headers:{...(data===undefined?{}:{'Content-Type':'application/json'}),...(token?{Authorization:`Bearer ${token}`} : {}),...headers},body:data===undefined?undefined:JSON.stringify(data)});return {status:response.status,data:await response.json()};}};}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
test('two independent guests queue into one authoritative battle; placement, energy, side and surrender enforced',async t=>{
 const api=await setup(t),a=(await api.request('/api/session',{name:'Alice'})).data,b=(await api.request('/api/session',{name:'Bob'})).data;
 assert.notEqual(a.token,b.token);assert.notEqual(a.me.code,b.me.code);
 assert.equal((await api.request('/api/state')).status,401);
 assert.equal((await api.request('/api/queue',{deck:['fake']},a.token)).status,400);
 assert.equal((await api.request('/api/queue',{deck},a.token)).data.queued,true);
 const joined=(await api.request('/api/queue',{deck},b.token)).data;
 const first=(await api.request('/api/state',undefined,a.token)).data;
 assert.equal(joined.room.ranked,true);assert.equal(joined.room.id,first.room.id);assert.equal(joined.room.side,'enemy');assert.equal(first.room.opponent.name,'Bob');
 await wait(2100);assert.equal((await api.request('/api/state',undefined,a.token)).data.room.battle.units.length,0,'online battle never deploys bots');
 assert.equal((await api.request('/api/action',{type:'deploy',index:0,x:23,y:25},a.token)).status,400);
 await wait(90);
 const placed=await api.request('/api/action',{type:'deploy',index:0,x:23,y:75,side:'enemy',damage:99999},a.token);
 assert.equal(placed.status,200);assert.equal(placed.data.room.battle.units[0].side,'player');assert.equal(placed.data.room.battle.units[0].damage,G.card(deck[0]).damage);
 assert.equal((await api.request('/api/action',{type:'deploy',index:0,x:77,y:25},b.token)).status,200);
 await wait(90);assert.equal((await api.request('/api/action',{type:'deploy',index:2,x:23,y:75},a.token)).status,200);
 await wait(90);assert.equal((await api.request('/api/action',{type:'deploy',index:3,x:23,y:75},a.token)).status,400,'oil is authoritative');
 assert.equal((await api.request('/api/leave',{},b.token)).data.room,null);
 const ended=(await api.request('/api/state',undefined,a.token)).data.room;assert.equal(ended.status,'finished');assert.equal(ended.battle.result,'win');
});
test('friend invitations restrict joining and identities survive restart',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'potato-multi-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const dataFile=path.join(dir,'players.json');
 const api=await setup(t,{dataFile}),a=(await api.request('/api/session',{name:'Host'})).data,b=(await api.request('/api/session',{name:'Friend'})).data,c=(await api.request('/api/session',{name:'Stranger'})).data;
 assert.equal((await api.request('/api/friends',{code:b.me.code},a.token)).data.friends[0].name,'Friend');
 const room=(await api.request('/api/room',{deck,friendCode:b.me.code},a.token)).data.room;
 assert.equal(room.ranked,false);assert.deepEqual((await api.request('/api/state',undefined,b.token)).data.invites,[{roomId:room.id,from:a.me}]);
 assert.equal((await api.request('/api/join',{roomId:room.id,deck},c.token)).status,403);
 assert.equal((await api.request('/api/join',{roomId:room.id,deck},b.token)).data.room.status,'playing');
 const disk=fs.readFileSync(dataFile,'utf8');assert.ok(!disk.includes(a.token));
 const restarted=await setup(t,{dataFile});const restored=(await restarted.request('/api/session',{},a.token)).data;
 assert.deepEqual(restored.me,a.me);assert.equal(restored.friends[0].code,b.me.code);assert.equal(restored.room,null);
});
test('cross-origin, secret-file exposure, unknown actions, and disconnect timeout are handled',async t=>{
 let time=Date.now();const api=await setup(t,{now:()=>time});
 assert.equal((await api.request('/api/session',{},null,{Origin:'https://attacker.example'})).status,403);
 for(const file of ['/server.cjs','/multiplayer-server.cjs','/.data/players.json','/package.json','/tests/multiplayer.test.cjs'])assert.equal((await fetch(api.base+file)).status,404);
 for(const file of ['/','/card-art.js','/game-core.js','/styles.css'])assert.equal((await fetch(api.base+file)).status,200);
 const a=(await api.request('/api/session',{})).data,b=(await api.request('/api/session',{})).data;
 await api.request('/api/queue',{deck},a.token);await api.request('/api/queue',{deck},b.token);
 assert.equal((await api.request('/api/action',{type:'setGold',gold:999999},a.token)).status,400);
 time+=20000;await api.request('/api/state',undefined,a.token);time+=11000;await wait(80);
 const r=(await api.request('/api/state',undefined,a.token)).data.room;assert.equal(r.status,'finished');assert.equal(r.battle.result,'win');
});
