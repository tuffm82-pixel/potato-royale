'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),G=require('../game-core.js');
test('reconnecting to a public match cannot award its saved rewards twice',()=>{
 let profile=G.newProfile();const battle=G.createBattle(profile,false);battle.id='1234567890abcdef12345678';battle.online=true;battle.result='win';
 const first=G.settle(profile,battle);assert.ok(first.delta>0);const trophies=profile.trophies,gold=profile.gold;
 profile=G.loadProfile(JSON.parse(JSON.stringify(profile)));const repeated=G.settle(profile,{...battle,settled:false});
 assert.equal(repeated.alreadyClaimed,true);assert.equal(profile.trophies,trophies);assert.equal(profile.gold,gold);assert.equal(profile.wins,1);
});
test('friend matches do not award trophies or consume public match claims',()=>{
 const p=G.newProfile(),b=G.createBattle(p,true);b.online=true;b.id='1234567890abcdef12345678';b.result='win';
 G.settle(p,b);assert.equal(p.trophies,0);assert.equal(p.gold,1500);assert.deepEqual(p.claimedMatches,[]);
});
