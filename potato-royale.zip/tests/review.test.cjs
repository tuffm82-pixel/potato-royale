const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const G=require('../game-core.js');

test('malformed chest entries do not discard otherwise valid saved progress',()=>{
 const saved=G.newProfile();saved.gold=4321;saved.trophies=1000;
 saved.owned['spud-scout']={level:4,copies:29};
 saved.chests=[null,{id:'valid',arena:2,ready:12345},false];
 const restored=G.loadProfile(JSON.parse(JSON.stringify(saved)));
 assert.equal(restored.gold,4321);assert.equal(restored.trophies,1000);
 assert.deepEqual(restored.owned['spud-scout'],{level:4,copies:29});
 assert.deepEqual(restored.chests,[{id:'valid',arena:2,ready:12345}]);
});

test('practice deployment, cycling, abilities and settlement preserve all saved progression',()=>{
 for(const result of ['win','loss','draw']){
  const saved=G.newProfile();saved.owned.barry={level:2,copies:8};saved.decks[0][0]='barry';
  saved.chests=[{id:'existing',arena:1,ready:12345}];
  const before=JSON.stringify(saved),b=G.createBattle(saved,true,()=>.5);
  b.ai=999;b.energy.player=10;
  assert.equal(G.deploy(b,'player',0,50,70),true);
  for(let i=0;i<12;i++)G.tick(b,.1);
  assert.equal(G.activateAbility(b,'player'),true);
  b.result=result;G.settle(saved,b);
  assert.equal(JSON.stringify(saved),before,result);
 }
});

test('Champion cooldown becomes ready at its deadline and charges again only on activation',()=>{
 const saved=G.newProfile();saved.owned.barry={level:1,copies:0};saved.decks[0][0]='barry';
 const b=G.createBattle(saved,true,()=>.5);b.energy.player=10;
 G.deploy(b,'player',0,50,70);b.units[0].ready=0;
 assert.equal(G.activateAbility(b,'player'),true);
 b.energy.player=10;b.elapsed=15.99;
 assert.equal(G.abilityReport(b,'player').ready,false);
 assert.equal(G.activateAbility(b,'player'),false);assert.equal(b.energy.player,10);
 b.elapsed=16;
 assert.equal(G.abilityReport(b,'player').ready,true);
 assert.equal(G.activateAbility(b,'player'),true);assert.equal(b.energy.player,7);
 assert.equal(b.units.filter(u=>u.cardId==='carrot-backup').length,4);
});

test('every catalog card and summoned guard has a real project-relative illustration asset',()=>{
 const root=path.resolve(__dirname,'..'),context={window:{}};
 vm.runInNewContext(fs.readFileSync(path.join(root,'card-art.js'),'utf8'),context);
 for(const [map,ids] of [[context.window.POTATO_ART,G.CARDS.map(c=>c.id)],[context.window.POTATO_UNITS,[...G.CARDS.map(c=>c.id),'carrot-backup']]]){
  for(const id of ids){
   assert.equal(typeof map[id],'string',id);
   assert.match(map[id],/^assets\/(cards|units)\/[a-z0-9-]+\.(svg|png)$/,id);
   const file=path.resolve(root,map[id]);assert.ok(fs.existsSync(file),id);
   if(file.endsWith('.svg'))assert.match(fs.readFileSync(file,'utf8'),/<svg\b/,id);else assert.equal(fs.readFileSync(file).subarray(1,4).toString(),'PNG',id);
  }
 }
});
