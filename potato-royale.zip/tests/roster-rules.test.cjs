const {test}=require('node:test');
const assert=require('node:assert/strict');
const G=require('../game-core.js');

function sketchBattle(roll=.1,side='player'){
 const profile=G.newProfile();profile.owned['three-french-men']={level:1,copies:2};profile.decks[0][0]='three-french-men';
 const b=G.createBattle(profile,true,()=>roll);b.online=true;b.energy[side]=10;b.decks[side][0]='three-french-men';
 assert.ok(G.deploy(b,side,0,50,side==='player'?70:30));b.units[0].ready=0;return b;
}

test('127 identities preserve legacy save keys and provide distinct renderable designs',()=>{
 assert.equal(G.CARDS.length,127);assert.equal(new Set(G.CARDS.map(c=>c.name)).size,127);
 const archetypes=new Map(),jobs=new Map(),designs=new Set();
 for(const c of G.CARDS){
  archetypes.set(c.archetype,(archetypes.get(c.archetype)||0)+1);
  const job=c.name.split(' ').at(-1);jobs.set(job,(jobs.get(job)||0)+1);
  assert.ok(c.visual.shape&&c.visual.prop&&c.visual.accent&&c.visual.detail);
  assert.equal(c.accessory,c.design.equipment);designs.add(c.design.shape+'/'+c.design.equipment);
 }
 assert.ok([...archetypes.values()].every(n=>n<=2));assert.ok([...jobs.values()].every(n=>n<=2));assert.equal(designs.size,127);
 assert.equal(G.card('three-french-men').name,'Stick Man');assert.equal(G.card('celery-wizard').name,'Vault Gobbler');
 const saved=G.newProfile();saved.owned['three-french-men']={level:4,copies:17};saved.decks[0][0]='three-french-men';
 const restored=G.loadProfile(JSON.parse(JSON.stringify(saved)));assert.deepEqual(restored.owned['three-french-men'],{level:4,copies:17});assert.equal(restored.decks[0][0],'three-french-men');
});

test('Sketch Summon probabilities and exact boundaries match the advertised rarities',()=>{
 assert.equal(G.SKETCH_SUMMON_TABLE.reduce((sum,e)=>sum+e.probability,0),1);
 for(const entry of G.SKETCH_SUMMON_TABLE)assert.equal(G.card(entry.cardId).rarity,entry.rarity);
 for(const [roll,id] of [[0,'spud-scout'],[.499999999,'spud-scout'],[.5,'tomato-wizard'],[.799999999,'tomato-wizard'],[.8,'pumpkin-wizard'],[.949999999,'pumpkin-wizard'],[.95,'potato-man'],[.999999999,'potato-man']])assert.equal(G.pickSketchSummon(()=>roll),id);
 for(const probability of ['50%','30%','15%','5%'])assert.ok(G.SKETCH_SUMMON_DESCRIPTION.includes(probability));
});

test('Stick Man deploys alone for two oil and summons one same-side ally for two oil',()=>{
 for(const side of ['player','enemy'])for(const roll of [.1,.6,.9,.99]){
  const b=sketchBattle(roll,side);assert.equal(b.units.length,1);assert.equal(b.energy[side],8);
  assert.equal(b.units[0].count,1);assert.equal(G.abilityReport(b,side).name,'Sketch Summon');
  assert.ok(G.activateAbility(b,side));assert.equal(b.energy[side],6);assert.equal(b.units.length,2);
  const ally=b.units[1];assert.equal(ally.cardId,G.pickSketchSummon(()=>roll));assert.equal(ally.side,side);assert.equal(ally.summoned,true);assert.equal(ally.ability,undefined);
  assert.equal(G.activateAbility(b,side),false);assert.equal(b.energy[side],6);
 }
});

test('summoned Potato Man never owns the ability and does not block redeploying Stick Man',()=>{
 const b=sketchBattle(.99);G.activateAbility(b,'player');const champion=b.units[0],summon=b.units[1];
 b.units=[summon,champion];assert.equal(G.abilityReport(b,'player').cardId,'three-french-men');
 champion.hp=0;assert.equal(G.abilityReport(b,'player').exists,false);
 b.decks.player[0]='three-french-men';assert.ok(G.deploy(b,'player',0,50,70));assert.equal(b.units.filter(u=>u.hp>0&&u.rarity==='champion').length,2);
 const profile=G.newProfile();for(const id of ['three-french-men','potato-man'])profile.owned[id]={level:1,copies:0};
 profile.decks[0][0]='three-french-men';profile.decks[0][1]='potato-man';assert.equal(G.deckReport(profile,profile.decks[0]).valid,false);
});

test('online simulation never invokes bot RNG, deploys cards or activates abilities',()=>{
 const b=sketchBattle(.1,'enemy');b.ai=-1;b.rng=()=>{throw Error('Bot RNG used online');};
 const hand=[...b.decks.enemy],cooldown=b.abilities.enemy;
 for(let i=0;i<20;i++)G.tick(b,.1);
 assert.deepEqual(b.decks.enemy,hand);assert.equal(b.units.length,1);assert.equal(b.abilities.enemy,cooldown);assert.equal(b.ai,-1);
});
